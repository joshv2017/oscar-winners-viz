/* * * * * * * * * * * * * *
*         Select           *
* * * * * * * * * * * * * */

// on decade change, update vis
function categoryChange() {
    myWinnerChart.wrangleData()
    myNomineeChart.wrangleData()
    myNormalizedNomChart.wrangleData()
    myNormalizedWinnerChart.wrangleData()
}